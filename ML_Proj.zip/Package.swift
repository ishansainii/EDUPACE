import PackageDescription

let package = Package(
    name: "PythonKit",
    dependencies: [
        .package(url: "https://github.com/pvieito/PythonKit.git", from: "0.7.0"),
    ],
    targets: [
        .target(
            name: "YourPackageName",
            dependencies: [
                .product(name: "PythonKit", package: "PythonKit"),
            ]),
    ]
)
