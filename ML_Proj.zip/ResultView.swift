//
//  ResultView.swift
//  ML_Proj
//
//  Created by Shivam Dwivedi on 23/11/23.
//

import Foundation


import SwiftUI

struct ResultView: View {
    @Binding var sex: String
    @Binding var age: String
    @Binding var address: String
    @Binding var famsize: String
    @Binding var Pstatus: String
    @Binding var Medu: String
    @Binding var Fedu: String
    @Binding var Mjob: String
    @Binding var Fjob: String
    @Binding var reason: String
    @Binding var guardian: String
    @Binding var traveltime: String
    @Binding var studytime: String
    @Binding var failures: String
    @Binding var schoolsup: String
    @Binding var famsup: String
    @Binding var paid: String
    @Binding var activities: String
    @Binding var nursery: String
    @Binding var higher: String
    @Binding var internet: String
    @Binding var romantic: String
    @Binding var famrel: String
    @Binding var freetime: String
    @Binding var goout: String
    @Binding var Dalc: String
    @Binding var Walc: String
    @Binding var health: String
    @Binding var absences: String
    @Binding var G1: String
    @Binding var desired_grade: String

    var body: some View {
        VStack {
            Text("Prediction Result")
                .font(.largeTitle)
                .padding()


            Text("Recommendation: Maintain current study time.")
                .font(.headline)
                .padding()
        }
        .navigationBarTitle("Result")
    }
}

struct ResultView_Previews: PreviewProvider {
    static var previews: some View {
        ResultView(sex: .constant(""), age: .constant(""), address: .constant(""), famsize: .constant(""), Pstatus: .constant(""), Medu: .constant(""), Fedu: .constant(""), Mjob: .constant(""), Fjob: .constant(""), reason: .constant(""), guardian: .constant(""), traveltime: .constant(""), studytime: .constant(""), failures: .constant(""), schoolsup: .constant(""), famsup: .constant(""), paid: .constant(""), activities: .constant(""), nursery: .constant(""), higher: .constant(""), internet: .constant(""), romantic: .constant(""), famrel: .constant(""), freetime: .constant(""), goout: .constant(""), Dalc: .constant(""), Walc: .constant(""), health: .constant(""), absences: .constant(""), G1: .constant(""), desired_grade: .constant(""))
    }
}
