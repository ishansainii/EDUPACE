//
//  ML_ProjApp.swift
//  ML_Proj
//
//  Created by Shivam Dwivedi on 23/11/23.
//

import SwiftUI

@main
struct ML_ProjApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
