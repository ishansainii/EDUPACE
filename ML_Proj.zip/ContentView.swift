import SwiftUI

struct ContentView: View {
    @State private var sex: String = ""
    @State private var age: String = ""
    @State private var address: String = ""
    @State private var famsize: String = ""
    @State private var Pstatus: String = ""
    @State private var Medu: String = ""
    @State private var Fedu: String = ""
    @State private var Mjob: String = ""
    @State private var Fjob: String = ""
    @State private var reason: String = ""
    @State private var guardian: String = ""
    @State private var traveltime: String = ""
    @State private var studytime: String = ""
    @State private var failures: String = ""
    @State private var schoolsup: String = ""
    @State private var famsup: String = ""
    @State private var paid: String = ""
    @State private var activities: String = ""
    @State private var nursery: String = ""
    @State private var higher: String = ""
    @State private var internet: String = ""
    @State private var romantic: String = ""
    @State private var famrel: String = ""
    @State private var freetime: String = ""
    @State private var goout: String = ""
    @State private var Dalc: String = ""
    @State private var Walc: String = ""
    @State private var health: String = ""
    @State private var absences: String = ""
    @State private var G1: String = ""
    @State private var desired_grade: String = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Personal Information")) {
                    TextField("Sex ('F' or 'M')", text: $sex)
                    TextField("Age (15 to 22)", text: $age)
                    Picker("Address Type", selection: $address) {
                        Text("Urban").tag("U")
                        Text("Rural").tag("R")
                    }
                    Picker("Family Size", selection: $famsize) {
                        Text("LE3").tag("LE3")
                        Text("GT3").tag("GT3")
                    }
                    Picker("Parent's Cohabitation Status", selection: $Pstatus) {
                        Text("T").tag("T")
                        Text("A").tag("A")
                    }
                    TextField("Mother's Education (0-4)", text: $Medu)
                    TextField("Father's Education (0-4)", text: $Fedu)
                    Picker("Mother's Job", selection: $Mjob) {
                        Text("teacher").tag("teacher")
                        Text("health").tag("health")
                        Text("services").tag("services")
                        Text("at_home").tag("at_home")
                        Text("other").tag("other")
                    }
                    Picker("Father's Job", selection: $Fjob) {
                        Text("teacher").tag("teacher")
                        Text("health").tag("health")
                        Text("services").tag("services")
                        Text("at_home").tag("at_home")
                        Text("other").tag("other")
                    }
                    Picker("Reason to Choose School", selection: $reason) {
                        Text("home").tag("home")
                        Text("reputation").tag("reputation")
                        Text("course").tag("course")
                        Text("other").tag("other")
                    }
                    Picker("Guardian", selection: $guardian) {
                        Text("mother").tag("mother")
                        Text("father").tag("father")
                        Text("other").tag("other")
                    }
                    Picker("Travel Time to School", selection: $traveltime) {
                        Text("<15 min.").tag("1")
                        Text("15 to 30 min.").tag("2")
                        Text("30 min. to 1 hour").tag("3")
                        Text(">1 hour").tag("4")
                    }
                    Picker("Weekly Study Time", selection: $studytime) {
                        Text("<2 hours").tag("1")
                        Text("2 to 5 hours").tag("2")
                        Text("5 to 10 hours").tag("3")
                        Text(">10 hours").tag("4")
                    }
                    TextField("Number of Past Class Failures", text: $failures)
                    Picker("Need Extra Educational Support", selection: $schoolsup) {
                        Text("yes").tag("yes")
                        Text("no").tag("no")
                    }
                    Picker("Have Family Educational Support", selection: $famsup) {
                        Text("yes").tag("yes")
                        Text("no").tag("no")
                    }
                    Picker("Extra Paid Classes Within Course Subject", selection: $paid) {
                        Text("yes").tag("yes")
                        Text("no").tag("no")
                    }
                    Picker("Participate in Extra-curricular Activities", selection: $activities) {
                        Text("yes").tag("yes")
                        Text("no").tag("no")
                    }
                    Picker("Attended Nursery School", selection: $nursery) {
                        Text("yes").tag("yes")
                        Text("no").tag("no")
                    }
                    Picker("Wants to Take Higher Education", selection: $higher) {
                        Text("yes").tag("yes")
                        Text("no").tag("no")
                    }
                    Picker("Access to Internet at Home", selection: $internet) {
                        Text("yes").tag("yes")
                        Text("no").tag("no")
                    }
                    Picker("In a Romantic Relationship", selection: $romantic) {
                        Text("yes").tag("yes")
                        Text("no").tag("no")
                    }
                    TextField("Quality of Family Relationships (1-5)", text: $famrel)
                    TextField("Free Time After School (1-5)", text: $freetime)
                    TextField("Going Out with Friends (1-5)", text: $goout)
                    TextField("Workday Alcohol Consumption (1-5)", text: $Dalc)
                    TextField("Weekend Alcohol Consumption (1-5)", text: $Walc)
                    TextField("Current Health Status (1-5)", text: $health)
                    TextField("Number of School Absences (0-93)", text: $absences)
                    TextField("Grade (1-20)", text: $G1)
                    TextField("Desired Grade (1-20)", text: $desired_grade)
                }

                NavigationLink(destination: ResultView(sex: $sex, age: $age, address: $address, famsize: $famsize, Pstatus: $Pstatus, Medu: $Medu, Fedu: $Fedu, Mjob: $Mjob, Fjob: $Fjob, reason: $reason, guardian: $guardian, traveltime: $traveltime, studytime: $studytime, failures: $failures, schoolsup: $schoolsup, famsup: $famsup, paid: $paid, activities: $activities, nursery: $nursery, higher: $higher, internet: $internet, romantic: $romantic, famrel: $famrel, freetime: $freetime, goout: $goout, Dalc: $Dalc, Walc: $Walc, health: $health, absences: $absences, G1: $G1, desired_grade: $desired_grade)) {
                    Text("Predict and Recommend")
                }
            }
            .navigationBarTitle("Study Time Predictor")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
